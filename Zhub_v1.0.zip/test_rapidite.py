import random
import time
from datetime import datetime

# Demande le pseudo
pseudo = input("Entre ton pseudo : ")

print("Dans ce jeu, un texte 'start' va s'afficher. Tape '/' le plus vite possible quand il apparaît !")
ready = input("Écris 'ready' pour commencer : ").lower()

if ready == "ready":
    time.sleep(random.uniform(3, 7))
    print("start")
    start = time.perf_counter()
    reponse = input()
    end = time.perf_counter()

    score = end - start

    if reponse == "/":
        print(f"Bravo {pseudo} ! Tu as répondu en {score:.3f} secondes.")
    else:
        print("Mauvaise touche ! Essaie encore.")

    # Enregistrement dans le fichier scores.txt
    with open("scores.txt", "a") as f:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{now} | {pseudo} | Test Rapidité | {score:.3f} secondes\n")
