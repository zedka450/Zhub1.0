import time
import random

print("=== Jeu de Maths Chronométré ===")
pseudo = input("Entre ton pseudo : ")

# Liste des questions avec difficulté progressive
questions = [
    ("5 + 7", 12),
    ("15 - 8", 7),
    ("3 x 9", 27),
    ("36 / 6", 6),
    ("2^3", 8),
    ("(4 * 5) + 6", 26)
]

erreurs = 0
start_time = time.time()

for q, reponse in questions:
    while True:
        try:
            user_answer = int(input(f"Combien fait {q} ? "))
            if user_answer == reponse:
                print("✅ Bonne réponse !")
                break
            else:
                print("❌ Mauvaise réponse, essaie encore.")
                erreurs += 1
        except ValueError:
            print("Merci d'écrire un nombre valide.")
            erreurs += 1

end_time = time.time()
temps_total = round(end_time - start_time, 2)

# Score : basé sur temps + erreurs
score = temps_total + erreurs

print("\n=== Résultat final ===")
print(f"{pseudo}, tu as fini en {temps_total} secondes avec {erreurs} erreurs.")
print(f"Ton score final est : {score}")

# Classement selon temps
if temps_total <= 10:
    print("🔥 Grand mathématicien !")
elif temps_total <= 13:
    print("👍 Pas mal du tout !")
else:
    print("😅 Petit joueur...")

# Enregistrement du score dans un fichier
with open("scores_maths.txt", "a") as f:
    f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {pseudo} | Temps: {temps_total}s | Erreurs: {erreurs} | Score: {score}\n")
