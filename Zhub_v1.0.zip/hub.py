import subprocess
import os
import glob

# Dictionnaire des jeux disponibles
# Dictionnaire des jeux disponibles
projets_locaux = {
    "jeu_nombre": "jeu_nombre.py",
    "test_rapidite": "test_rapidite.py",
    "jeu_maths": "jeu_maths.py",
    "minuteur_chronometre": "minuteur_chronometre.py",
    "zos_os": "mini-os.py"   
}

# Fonction pour nettoyer l'écran
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

# Afficher le classement complet
def afficher_classement():
    fichiers = glob.glob("scores*.txt")
    if not fichiers:
        print("Aucun score enregistré pour le moment.\n")
        return
    print("\n--- Classement global ---")
    for fpath in fichiers:
        print(f"\n== {os.path.basename(fpath)} ==")
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                contenu = f.read().strip()
                print(contenu if contenu else "(fichier vide)")
        except Exception as e:
            print(f"(Impossible de lire {fpath}: {e})")
    print("-------------------------\n")

# Afficher les scores pour un pseudo
def afficher_scores_joueur(pseudo):
    fichiers = glob.glob("scores*.txt")
    trouve = False
    for fpath in fichiers:
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                for ligne in f:
                    if pseudo.lower() in ligne.lower():
                        print(f"[{os.path.basename(fpath)}] {ligne.strip()}")
                        trouve = True
        except Exception as e:
            print(f"(Impossible de lire {fpath}: {e})")
    if not trouve:
        print(f"Aucun score trouvé pour le pseudo '{pseudo}'.")
    print("-------------------------\n")

# Message d'accueil
clear()
print("=== Bienvenue dans le Hub ===")
print("Si vous avez des suggestions, envoyez-moi un mail à : zedka.le.vrai.pro@gmail.com\n")

# Boucle principale
while True:
    choix = input("Tape le nom du jeu ou une commande ('quit', '/clear', 'score_joueur', 'score_global') : ").strip().lower()

    if choix == "quit":
        print("Fermeture du hub. À bientôt !")
        break

    elif choix in projets_locaux:
        fichier_script = projets_locaux[choix]
        if not os.path.exists(fichier_script):
            print(f"Le fichier {fichier_script} est introuvable.")
            continue
        try:
            subprocess.run(["python", fichier_script])
        except Exception as e:
            print(f"Erreur en lançant {fichier_script} : {e}")

    elif choix == "/clear":
        clear()
        continue

    elif choix == "score_joueur":
        pseudo = input("Entrez le pseudo à rechercher : ").strip()
        if pseudo:
            afficher_scores_joueur(pseudo)
        else:
            print("Pseudo vide. Annulation.")
        continue

    elif choix == "score_global":
        afficher_classement()
        input("Appuyez sur Entrée pour revenir au menu...")
        clear()
        continue

    else:
        print(f"Commande ou projet inconnu : {choix}\n")
