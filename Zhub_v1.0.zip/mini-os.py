#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mini-OS en un fichier Python (utilise uniquement la stdlib).
Fonctions: prompt, ls, cd, pwd, cat, write, rm, mkdir, rmdir, run (subprocess),
py (mini-REPL), http (serveur simple), wget (téléchargement), sysinfo, clear, exit.
"""
import os
import sys
import shutil
import subprocess
import threading
import socketserver
import http.server
import urllib.request
import json
import time
import platform
from pathlib import Path

HOME = Path.home()
ENV = {
    "cwd": Path.cwd(),
    "user": os.getenv("USER") or os.getenv("USERNAME") or "guest",
    "root": False
}

WELCOME = r"""
 _______  _       ____   ____   _____
|__   __|| |     / __ \ / __ \ / ____|
   | |   | |    | |  | | |  | | (___
   | |   | |    | |  | | |  | |\___ \
   | |   | |____| |__| | |__| |____) |
   |_|   |______\____/ \____/|_____/

Mini-OS (single-file) — commandes: help
"""

def echo(*parts):
    print(*parts)

def list_dir(path):
    try:
        p = Path(path)
        if not p.exists():
            echo("chemin introuvable:", path)
            return
        for entry in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            kind = "d" if entry.is_dir() else "-"
            size = entry.stat().st_size
            mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(entry.stat().st_mtime))
            echo(f"{kind} {entry.name}\t{size} bytes\t{mtime}")
    except PermissionError:
        echo("Permission denied:", path)

def read_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            print(f.read())
    except Exception as e:
        echo("Erreur lecture:", e)

def write_file(path, content, append=False):
    mode = 'a' if append else 'w'
    try:
        with open(path, mode, encoding='utf-8') as f:
            f.write(content)
        echo("OK")
    except Exception as e:
        echo("Erreur écriture:", e)

def rm_path(path):
    p = Path(path)
    if not p.exists():
        echo("Introuvable:", path); return
    try:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        echo("Supprimé:", path)
    except Exception as e:
        echo("Erreur suppression:", e)

def mkdir_path(path):
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
        echo("OK")
    except Exception as e:
        echo("Erreur mkdir:", e)

def run_command(args):
    try:
        completed = subprocess.run(args, shell=False)
        return completed.returncode
    except FileNotFoundError:
        echo("Commande introuvable:", args[0])
    except Exception as e:
        echo("Erreur execution:", e)
    return 1

def start_http_server(port=8000, directory=None):
    directory = directory or str(ENV["cwd"])
    handler = http.server.SimpleHTTPRequestHandler
    # Python's handler respects os.chdir for directory in 3.7+; use socketserver
    try:
        os.chdir(directory)
    except Exception as e:
        echo("Impossible de changer de répertoire pour le serveur:", e); return

    class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
        allow_reuse_address = True

    def server_thread():
        with ThreadedTCPServer(("", port), handler) as httpd:
            echo(f"Serveur HTTP en écoute sur http://0.0.0.0:{port} (répertoire: {directory})")
            try:
                httpd.serve_forever()
            except Exception:
                pass

    t = threading.Thread(target=server_thread, daemon=True)
    t.start()
    return t

def wget(url, out=None):
    out = out or os.path.basename(url) or "download"
    try:
        with urllib.request.urlopen(url) as resp, open(out, 'wb') as f:
            shutil.copyfileobj(resp, f)
        echo("Téléchargé ->", out)
    except Exception as e:
        echo("Erreur wget:", e)

def python_repl():
    echo("Mini-REPL Python (exit() pour revenir)")
    local = {}
    while True:
        try:
            line = input(">>> ")
        except EOFError:
            echo()
            break
        if line.strip() in ("exit()", "quit()"):
            break
        try:
            # try eval then exec
            try:
                val = eval(line, globals(), local)
                if val is not None:
                    echo(repr(val))
            except SyntaxError:
                exec(line, globals(), local)
        except Exception as e:
            echo("Erreur:", e)

def sysinfo():
    info = {
        "platform": platform.system(),
        "platform-release": platform.release(),
        "platform-version": platform.version(),
        "architecture": platform.machine(),
        "hostname": socket_name(),
        "python": platform.python_version(),
        "cwd": str(ENV["cwd"]),
        "user": ENV["user"]
    }
    echo(json.dumps(info, indent=2, ensure_ascii=False))

def socket_name():
    try:
        return socket.gethostname()
    except Exception:
        return "unknown"

def clear_screen():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")

HELP_TEXT = """
Commandes disponibles:
  help                     - affiche cette aide
  ls [path]                - lister un répertoire
  cd [path]                - changer le répertoire courant
  pwd                      - afficher le répertoire courant
  cat <file>               - afficher un fichier texte
  write <file>             - écriture interactive (CTRL-D pour finir)
  append <file>            - ajouter au fichier interactif
  rm <path>                - supprimer fichier ou dossier
  mkdir <path>             - créer répertoire(s)
  run <cmd> [args...]      - lancer une commande externe
  py                       - mini-REPL Python
  http [port] [dir]        - lancer serveur HTTP (en arrière-plan)
  wget <url> [out]         - télécharger un fichier
  sysinfo                  - infos système basiques
  clear                    - nettoyer l'écran
  exit                     - quitter
"""

def prompt():
    cwd = ENV["cwd"]
    user = ENV["user"]
    base = Path(cwd).name or '/'
    return f"{user}@mini-os:{base}$ "

def parse_and_exec(line):
    line = line.strip()
    if not line:
        return
    parts = line.split()
    cmd = parts[0]
    args = parts[1:]

    if cmd == "help":
        print(HELP_TEXT)
    elif cmd == "ls":
        path = args[0] if args else str(ENV["cwd"])
        list_dir(Path(ENV["cwd"]) / path if not Path(path).is_absolute() else Path(path))
    elif cmd == "cd":
        if not args:
            target = HOME
        else:
            target = Path(args[0])
            if not target.is_absolute():
                target = ENV["cwd"] / target
        if target.exists() and target.is_dir():
            ENV["cwd"] = target.resolve()
            try:
                os.chdir(ENV["cwd"])
            except Exception:
                pass
        else:
            echo("Répertoire introuvable:", target)
    elif cmd == "pwd":
        echo(str(ENV["cwd"]))
    elif cmd == "cat":
        if not args:
            echo("Usage: cat <file>")
        else:
            p = Path(args[0])
            if not p.is_absolute():
                p = ENV["cwd"] / p
            read_file(p)
    elif cmd in ("write", "append"):
        if not args:
            echo("Usage: write <file>")
        else:
            p = Path(args[0])
            if not p.is_absolute():
                p = ENV["cwd"] / p
            echo("Entrez le texte. Finir avec EOF (Ctrl-D / Ctrl-Z puis Enter).")
            try:
                content = sys.stdin.read() if os.isatty(sys.stdin.fileno()) else sys.stdin.read()
            except Exception:
                # fallback to interactive multi-line
                lines = []
                try:
                    while True:
                        lines.append(input())
                except EOFError:
                    pass
                content = "\n".join(lines) + "\n"
            write_file(p, content, append=(cmd=="append"))
    elif cmd == "rm":
        if not args:
            echo("Usage: rm <path>")
        else:
            p = Path(args[0])
            if not p.is_absolute():
                p = ENV["cwd"] / p
            rm_path(p)
    elif cmd == "mkdir":
        if not args:
            echo("Usage: mkdir <path>")
        else:
            p = Path(args[0])
            if not p.is_absolute():
                p = ENV["cwd"] / p
            mkdir_path(p)
    elif cmd == "run":
        if not args:
            echo("Usage: run <cmd> [args...]")
        else:
            # run external command in a subprocess
            try:
                run_command(args)
            except Exception as e:
                echo("Erreur run:", e)
    elif cmd == "py":
        python_repl()
    elif cmd == "http":
        port = 8000
        directory = str(ENV["cwd"])
        if args:
            try:
                port = int(args[0])
                if len(args) > 1:
                    directory = args[1]
                    if not Path(directory).is_absolute():
                        directory = str(ENV["cwd"] / directory)
            except ValueError:
                echo("Port invalide.")
                return
        start_http_server(port=port, directory=directory)
    elif cmd == "wget":
        if not args:
            echo("Usage: wget <url> [out]")
        else:
            url = args[0]
            out = args[1] if len(args) > 1 else None
            wget(url, out)
    elif cmd == "sysinfo":
        sysinfo()
    elif cmd == "clear":
        clear_screen()
    elif cmd == "exit":
        echo("Bye.")
        sys.exit(0)
    else:
        echo(f"Commande inconnue: {cmd}. Utilise 'help' pour la liste.")

def main():
    echo(WELCOME)
    echo("Tape 'help' pour la liste des commandes.")
    try:
        while True:
            try:
                line = input(prompt())
            except EOFError:
                echo()
                break
            except KeyboardInterrupt:
                echo()
                continue
            parse_and_exec(line)
    except SystemExit:
        raise
    except Exception as e:
        echo("Erreur inattendue:", e)
    echo("Mini-OS terminé.")

if __name__ == "__main__":
    main()
