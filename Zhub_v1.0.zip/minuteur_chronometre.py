import os
import sys
import platform
import time

print("Ceci est un minuteur / chronomètre.")
print("Tapez 'crono' pour le chronomètre et 'minu' pour le minuteur.")
print("Pour annuler, tapez '/back' à tout moment.")

while True:
    choix = input("Minuteur ou chronomètre ? ").strip().lower()
    
    if choix == "crono":
        print("Tu as choisi le chronomètre.")
        start_cmd = input("Écris 'start' pour commencer : ").strip().lower()
        if start_cmd == "start":
            startc = time.time()
            print("Le chronomètre a commencé. Tape '/stop' pour arrêter.")
            stop_cmd = input().strip().lower()
            if stop_cmd == "/stop":
                endc = time.time()
                temp = endc - startc
                print(f"Ça a duré {temp:.2f} secondes.")
        continue

    elif choix == "minu":
        try:
            sec = int(input("Combien de secondes ? ").strip())
            minute = int(input("Combien de minutes ? ").strip())
        except ValueError:
            print("Merci de rentrer un nombre entier.")
            continue

        temps_total = sec + (minute * 60)
        print(f"Minuteur lancé pour {temps_total} secondes...")
        time.sleep(temps_total)

        # Jouer le son selon le système
        systeme = platform.system()
        if systeme == "Windows":
            os.system("start sonnerie.wav")
        elif systeme == "Darwin":  # macOS
            os.system("afplay sonnerie.wav")
        else:  # Linux
            os.system("aplay sonnerie.wav")
        continue

    elif choix == "/back":
        print("Retour au menu.")
        os.execl(sys.executable, sys.executable, *sys.argv)

    else:
        print("Commande inconnue, réessaye.")

        


