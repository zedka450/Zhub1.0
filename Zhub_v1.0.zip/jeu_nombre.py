import random
import time
from datetime import datetime

# Demande le pseudo
pseudo = input("Entre ton pseudo : ")

# Nombre aléatoire à deviner
bon_code = random.randint(1, 100)
mot_start = "start"

# Demande à l'utilisateur de taper "start"
user_input = input(f"Pour commencer le jeu 'devine le nombre', tapez {mot_start} : ")
if mot_start in user_input.lower():  # accepte majuscules/minuscules
    start_time = time.time()
    nombre_essai = 30

    while nombre_essai > 0:
        try:
            user_guess = int(input("Votre essai : "))
        except ValueError:
            print("Merci de taper un nombre valide.")
            continue

        if user_guess == bon_code:
            essais_utilises = 30 - nombre_essai + 1
            print(f"Bravo ! Tu as trouvé le bon nombre en {essais_utilises} essais !")
            break
        else:
            nombre_essai -= 1
            if user_guess < bon_code:
                print(f"Trop petit ! Il te reste {nombre_essai} essais.")
            else:
                print(f"Trop grand ! Il te reste {nombre_essai} essais.")
    else:
        essais_utilises = 30
        print(f"Désolé, tu n'as plus d'essais. Le bon nombre était {bon_code}.")

    end_time = time.time()
    temps_total = int(end_time - start_time)
    print(f"Temps total du jeu : {temps_total} secondes.")

    # Enregistrement dans le fichier scores.txt
    with open("scores.txt", "a") as f:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{now} | {pseudo} | Jeu Nombre | {essais_utilises} essais en {temps_total} secondes\n")

else:
    print("Tu n'as pas tapé 'start', le jeu ne démarre pas.")
